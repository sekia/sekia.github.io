package Parse::KyotoUniversityTextCorpus::Types;

use Mouse::Util::TypeConstraints;

enum 'Parse::KyotoUniversityTextCorpus::DependencyType'
  => [qw/apposition dependency parallel/];

duck_type 'Parse::KyotoUniversityTextCorpus::Morpheme'
  => [qw/as_string is_eos surface/];

duck_type 'Parse::KyotoUniversityTextCorpus::MorphemeParser' => [qw/parse/];

no Mouse::Util::TypeConstraints;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Parse::KyotoUniversityTextCorpus::Types

=head1 VERSION

version 0.01

=head1 AUTHOR

Koichi SATOH <sekia@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2013 by Koichi SATOH.

This is free software, licensed under:

  The MIT (X11) License

=cut
