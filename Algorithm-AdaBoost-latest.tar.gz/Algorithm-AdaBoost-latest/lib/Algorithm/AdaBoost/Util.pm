package Algorithm::AdaBoost::Util;

use strict;
use warnings;
use v5.10;
use Carp qw//;

our @CARP_NOT;

sub import {
  my ($class, @symbols) = @_;

  my $caller = caller;
  for my $symbol (@symbols) {
    no strict 'refs';
    Carp::croak(qq/Not exportable function: "$symbol"/) unless defined &$symbol;
    *{ "${caller}::${symbol}" } = \&$symbol;
  }
}

sub assert_no_rest_params(\%) {
  my ($params) = @_;

  if (%$params) {
    local @CARP_NOT = (scalar caller);
    Carp::croak(
      'Unknown parameter(s): ',
      join ', ', map { qq/"$_"/ } keys %$params,
    );
  }
}

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Algorithm::AdaBoost::Util

=head1 VERSION

version 0.01

=head1 AUTHOR

Koichi SATOH <sekia@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by Koichi SATOH.

This is free software, licensed under:

  The MIT (X11) License

=cut
